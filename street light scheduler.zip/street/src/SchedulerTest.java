import java.time.LocalDate;
import java.time.Year;
import java.util.List;

public class SchedulerTest {
    public static void main(String[] args) {
        testNormalMonday();
        testHolidayMonday();
        testNormalTuesday();
        testHolidayTuesday();
        testLeapYear();
        testNonLeapYear();
        testPastYearNationalHoliday();
        testBuiltInAreaObservances();
        System.out.println("All scheduler tests passed.");
    }

    private static void testNormalMonday() {
        LightController controller = new LightController();
        boolean[] states = controller.getLightStates(LocalDate.of(2026, 1, 5), false);
        assertLights(states, true, false, true, false, true, false, true);
    }

    private static void testHolidayMonday() {
        LightController controller = new LightController();
        boolean[] states = controller.getLightStates(LocalDate.of(2026, 1, 5), true);
        assertLights(states, false, false, false, false, false, false, false);
    }

    private static void testNormalTuesday() {
        LightController controller = new LightController();
        boolean[] states = controller.getLightStates(LocalDate.of(2026, 1, 6), false);
        assertLights(states, false, true, false, true, false, true, false);
    }

    private static void testHolidayTuesday() {
        LightController controller = new LightController();
        boolean[] states = controller.getLightStates(LocalDate.of(2026, 1, 6), true);
        assertLights(states, false, false, false, false, false, false, false);
    }

    private static void testLeapYear() {
        HolidayManager holidayManager = new HolidayManager();
        CalendarGenerator generator = new CalendarGenerator(holidayManager, new LightController());
        List<ScheduleEntry> entries = generator.generateYear(2028);
        if (entries.size() != 366) {
            throw new AssertionError("Expected 366 rows for leap year 2028.");
        }
    }

    private static void testNonLeapYear() {
        HolidayManager holidayManager = new HolidayManager();
        CalendarGenerator generator = new CalendarGenerator(holidayManager, new LightController());
        List<ScheduleEntry> entries = generator.generateYear(2027);
        if (entries.size() != 365) {
            throw new AssertionError("Expected 365 rows for non-leap year 2027.");
        }
    }

    private static void testPastYearNationalHoliday() {
        HolidayManager holidayManager = new HolidayManager();
        if (!holidayManager.isHoliday(LocalDate.of(Year.now().getValue() - 25, 1, 26))) {
            throw new AssertionError("Expected Republic Day to be available for the past 25-year range.");
        }
    }

    private static void testBuiltInAreaObservances() {
        HolidayManager holidayManager = new HolidayManager();
        int year = Year.now().getValue();
        if (!holidayManager.isHoliday(LocalDate.of(year, 1, 15))) {
            throw new AssertionError("Expected Army Day to be available.");
        }
        if (!holidayManager.isHoliday(LocalDate.of(year, 7, 1))) {
            throw new AssertionError("Expected Doctors' Day / Health Checkup Day to be available.");
        }
    }

    private static void assertLights(boolean[] actual, boolean... expected) {
        if (actual.length != expected.length) {
            throw new AssertionError("Light count mismatch.");
        }
        for (int i = 0; i < actual.length; i++) {
            if (actual[i] != expected[i]) {
                throw new AssertionError("Light " + (i + 1) + " expected "
                        + expected[i] + " but was " + actual[i]);
            }
        }
    }
}
