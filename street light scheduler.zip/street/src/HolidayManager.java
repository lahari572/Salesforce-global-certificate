import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class HolidayManager {
    private final Map<LocalDate, Holiday> holidays = new HashMap<>();
    private final Path dataFile = Paths.get("data", "holidays.csv");
    private final Path customFile = Paths.get("data", "custom_holidays.csv");

    public HolidayManager() {
        reload();
    }

    public final void reload() {
        holidays.clear();
        int currentYear = Year.now().getValue();
        for (int year = currentYear - Utils.PAST_YEAR_LIMIT;
                year <= currentYear + Utils.FUTURE_YEAR_LIMIT; year++) {
            addBuiltInNationalHolidays(year);
        }
        loadCsv(dataFile, "CSV Database");
        loadCsv(customFile, "Custom Holiday");
    }

    public Optional<Holiday> getHoliday(LocalDate date) {
        return Optional.ofNullable(holidays.get(date));
    }

    public boolean isHoliday(LocalDate date) {
        return holidays.containsKey(date);
    }

    public List<Holiday> getHolidaysForYear(int year) {
        List<Holiday> result = new ArrayList<>();
        for (Holiday holiday : holidays.values()) {
            if (holiday.getDate().getYear() == year) {
                result.add(holiday);
            }
        }
        result.sort(Comparator.comparing(Holiday::getDate));
        return result;
    }

    public Optional<Holiday> getNextHoliday(LocalDate fromDate) {
        return holidays.values().stream()
                .filter(holiday -> !holiday.getDate().isBefore(fromDate))
                .sorted(Comparator.comparing(Holiday::getDate))
                .findFirst();
    }

    public void addCustomHoliday(LocalDate date, String name) throws IOException {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Holiday name is required.");
        }
        Files.createDirectories(customFile.getParent());
        boolean newFile = !Files.exists(customFile);
        try (BufferedWriter writer = Files.newBufferedWriter(customFile, StandardCharsets.UTF_8,
                Files.exists(customFile) ? java.nio.file.StandardOpenOption.APPEND
                        : java.nio.file.StandardOpenOption.CREATE)) {
            if (newFile) {
                writer.write("date,name");
                writer.newLine();
            }
            writer.write(Utils.formatDate(date));
            writer.write(",");
            writer.write(escapeCsv(name.trim()));
            writer.newLine();
        }
        holidays.put(date, new Holiday(date, name.trim(), "Custom Holiday"));
    }

    private void addBuiltInNationalHolidays(int year) {
        addHoliday(new Holiday(LocalDate.of(year, 1, 15), "Army Day", "Built-in Observance"));
        addHoliday(new Holiday(LocalDate.of(year, 1, 26), "Republic Day", "Built-in National Holiday"));
        addHoliday(new Holiday(LocalDate.of(year, 7, 1), "Doctors' Day / Health Checkup Day", "Built-in Observance"));
        addHoliday(new Holiday(LocalDate.of(year, 8, 15), "Independence Day", "Built-in National Holiday"));
        addHoliday(new Holiday(LocalDate.of(year, 10, 2), "Gandhi Jayanti", "Built-in National Holiday"));
    }

    private void loadCsv(Path path, String source) {
        if (!Files.exists(path)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                if (firstLine && line.toLowerCase().startsWith("date,")) {
                    firstLine = false;
                    continue;
                }
                firstLine = false;
                List<String> columns = parseCsvLine(line);
                if (columns.size() < 2) {
                    continue;
                }
                LocalDate date = Utils.parseDate(columns.get(0));
                String name = columns.get(1).trim();
                if (!name.isEmpty()) {
                    addHoliday(new Holiday(date, name, source));
                }
            }
        } catch (Exception ex) {
            System.err.println("Could not load holidays from " + path + ": " + ex.getMessage());
        }
    }

    private void addHoliday(Holiday holiday) {
        holidays.put(holiday.getDate(), holiday);
    }

    private List<String> parseCsvLine(String line) {
        if (line == null) {
            return Collections.emptyList();
        }

        List<String> columns = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                columns.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        columns.add(current.toString());
        return columns;
    }

    private String escapeCsv(String text) {
        if (text.contains(",") || text.contains("\"")) {
            return "\"" + text.replace("\"", "\"\"") + "\"";
        }
        return text;
    }
}
