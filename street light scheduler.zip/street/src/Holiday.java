import java.time.LocalDate;

public class Holiday {
    private final LocalDate date;
    private final String name;
    private final String source;

    public Holiday(LocalDate date, String name, String source) {
        this.date = date;
        this.name = name;
        this.source = source;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String getSource() {
        return source;
    }
}
