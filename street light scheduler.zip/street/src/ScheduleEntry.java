import java.time.LocalDate;

public class ScheduleEntry {
    private final LocalDate date;
    private final String day;
    private final boolean holiday;
    private final String holidayName;
    private final String lightPattern;
    private final String activeLights;
    private final String status;
    private final boolean[] lightStates;

    public ScheduleEntry(LocalDate date, String day, boolean holiday, String holidayName,
            String lightPattern, String activeLights, String status, boolean[] lightStates) {
        this.date = date;
        this.day = day;
        this.holiday = holiday;
        this.holidayName = holidayName;
        this.lightPattern = lightPattern;
        this.activeLights = activeLights;
        this.status = status;
        this.lightStates = lightStates.clone();
    }

    public LocalDate getDate() {
        return date;
    }

    public String getDay() {
        return day;
    }

    public boolean isHoliday() {
        return holiday;
    }

    public String getHolidayName() {
        return holidayName;
    }

    public String getLightPattern() {
        return lightPattern;
    }

    public String getActiveLights() {
        return activeLights;
    }

    public String getStatus() {
        return status;
    }

    public boolean[] getLightStates() {
        return lightStates.clone();
    }
}
