import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class TableRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
            boolean hasFocus, int row, int column) {
        Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        if (isSelected) {
            component.setBackground(new Color(0, 121, 107));
            component.setForeground(Color.WHITE);
            return component;
        }

        int modelRow = table.convertRowIndexToModel(row);
        Object status = table.getModel().getValueAt(modelRow, 6);
        boolean holidayMode = "Holiday Mode".equals(status);
        component.setBackground(holidayMode ? new Color(65, 30, 36)
                : (row % 2 == 0 ? new Color(245, 248, 250) : Color.WHITE));
        component.setForeground(holidayMode ? new Color(255, 230, 230) : new Color(28, 38, 48));
        return component;
    }
}
