import java.awt.Component;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class ExportManager {
    public void exportCsv(Component parent, List<ScheduleEntry> entries, int year) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export Yearly Schedule");
        chooser.setSelectedFile(new File("street_light_schedule_" + year + ".csv"));
        int choice = chooser.showSaveDialog(parent);
        if (choice != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File file = chooser.getSelectedFile();
        try {
            writeCsv(file, entries);
            JOptionPane.showMessageDialog(parent, "Schedule exported successfully:\n" + file.getAbsolutePath(),
                    "Export Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(parent, "Export failed: " + ex.getMessage(),
                    "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void writeCsv(File file, List<ScheduleEntry> entries) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
            writer.write("Date,Day,Government Holiday,Holiday Name,Light Pattern,Active Lights,Status");
            writer.newLine();
            for (ScheduleEntry entry : entries) {
                writer.write(csv(Utils.formatDate(entry.getDate())));
                writer.write(",");
                writer.write(csv(entry.getDay()));
                writer.write(",");
                writer.write(entry.isHoliday() ? "Yes" : "No");
                writer.write(",");
                writer.write(csv(entry.getHolidayName()));
                writer.write(",");
                writer.write(csv(entry.getLightPattern()));
                writer.write(",");
                writer.write(csv(entry.getActiveLights()));
                writer.write(",");
                writer.write(csv(entry.getStatus()));
                writer.newLine();
            }
        }
    }

    private String csv(String text) {
        if (text == null) {
            return "";
        }
        if (text.contains(",") || text.contains("\"") || text.contains("\n")) {
            return "\"" + text.replace("\"", "\"\"") + "\"";
        }
        return text;
    }
}
