import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // Swing will safely fall back to the default look and feel.
            }

            StreetLightGUI gui = new StreetLightGUI();
            gui.setVisible(true);
        });
    }
}
