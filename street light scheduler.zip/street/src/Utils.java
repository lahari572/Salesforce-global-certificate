import java.awt.Color;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

public final class Utils {
    public static final int PAST_YEAR_LIMIT = 25;
    public static final int FUTURE_YEAR_LIMIT = 50;
    public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final Color BACKGROUND = new Color(18, 28, 38);
    public static final Color PANEL = new Color(28, 42, 56);
    public static final Color PANEL_DARK = new Color(22, 33, 45);
    public static final Color TEXT = new Color(238, 244, 249);
    public static final Color MUTED_TEXT = new Color(175, 190, 202);
    public static final Color ACCENT = new Color(0, 150, 136);
    public static final Color ON = new Color(36, 196, 92);
    public static final Color OFF = new Color(120, 130, 140);
    public static final Color HOLIDAY = new Color(230, 72, 78);

    private Utils() {
    }

    public static String formatDate(LocalDate date) {
        return date.format(DATE_FORMAT);
    }

    public static LocalDate parseDate(String text) {
        return LocalDate.parse(text.trim(), DATE_FORMAT);
    }

    public static String dayName(LocalDate date) {
        return date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    }

    public static String monthName(int month) {
        return Month.of(month).getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    }

    public static boolean isOddPatternDay(DayOfWeek day) {
        return day == DayOfWeek.MONDAY
                || day == DayOfWeek.WEDNESDAY
                || day == DayOfWeek.FRIDAY
                || day == DayOfWeek.SUNDAY;
    }

    public static String activeLightsText(boolean[] states) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < states.length; i++) {
            if (states[i]) {
                if (builder.length() > 0) {
                    builder.append(", ");
                }
                builder.append(i + 1);
            }
        }
        return builder.length() == 0 ? "None" : builder.toString();
    }

    public static String patternName(boolean holidayMode, boolean oddLightsOn) {
        String base = oddLightsOn ? "Odd Lights ON" : "Even Lights ON";
        return holidayMode ? "Holiday - No Lights" : "Normal - " + base;
    }
}
