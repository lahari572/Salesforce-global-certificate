import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class DashboardPanel extends JPanel {
    private final JLabel currentDate = valueLabel();
    private final JLabel currentDay = valueLabel();
    private final JLabel currentHoliday = valueLabel();
    private final JLabel holidayName = valueLabel();
    private final JLabel activeLights = valueLabel();
    private final JLabel totalHolidays = valueLabel();
    private final JLabel selectedYear = valueLabel();
    private final JLabel nextHoliday = valueLabel();

    public DashboardPanel() {
        setLayout(new GridLayout(2, 4, 10, 10));
        setBackground(Utils.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(tile("Current Date", currentDate));
        add(tile("Current Day", currentDay));
        add(tile("Current Holiday", currentHoliday));
        add(tile("Holiday Name", holidayName));
        add(tile("Active Lights", activeLights));
        add(tile("Total Holidays", totalHolidays));
        add(tile("Selected Year", selectedYear));
        add(tile("Next Holiday", nextHoliday));
    }

    public void updateDashboard(ScheduleEntry selectedEntry, int year, int holidayCount,
            Optional<Holiday> nextHolidayValue) {
        currentDate.setText(Utils.formatDate(selectedEntry.getDate()));
        currentDay.setText(selectedEntry.getDay());
        currentHoliday.setText(selectedEntry.isHoliday() ? "Yes" : "No");
        holidayName.setText(selectedEntry.getHolidayName());
        activeLights.setText(selectedEntry.getActiveLights());
        totalHolidays.setText(String.valueOf(holidayCount));
        selectedYear.setText(String.valueOf(year));
        nextHoliday.setText(nextHolidayValue
                .map(h -> Utils.formatDate(h.getDate()) + " - " + h.getName())
                .orElse("No upcoming holiday"));
    }

    public void updateToday(HolidayManager holidayManager, LightController lightController, int year) {
        LocalDate today = LocalDate.now();
        Optional<Holiday> holiday = holidayManager.getHoliday(today);
        boolean[] states = lightController.getLightStates(today, holiday.isPresent());
        ScheduleEntry todayEntry = new ScheduleEntry(today, Utils.dayName(today), holiday.isPresent(),
                holiday.map(Holiday::getName).orElse("-"),
                lightController.getPatternName(today, holiday.isPresent()),
                Utils.activeLightsText(states),
                holiday.isPresent() ? "Holiday Mode" : "Normal",
                states);
        updateDashboard(todayEntry, year, holidayManager.getHolidaysForYear(year).size(),
                holidayManager.getNextHoliday(today));
    }

    private JPanel tile(String title, JLabel value) {
        JPanel panel = new MetricTile();
        panel.setLayout(new BorderLayout(4, 4));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(58, 90, 106)),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Utils.MUTED_TEXT);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(value, BorderLayout.CENTER);
        return panel;
    }

    private JLabel valueLabel() {
        JLabel label = new JLabel("-");
        label.setForeground(Utils.TEXT);
        label.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label.setHorizontalAlignment(SwingConstants.LEFT);
        return label;
    }

    private static class MetricTile extends JPanel {
        MetricTile() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Utils.PANEL);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.setColor(new Color(0, 150, 136, 45));
            g2.fillRoundRect(0, getHeight() - 5, getWidth(), 5, 12, 12);
            g2.dispose();
            super.paintComponent(graphics);
        }
    }
}
