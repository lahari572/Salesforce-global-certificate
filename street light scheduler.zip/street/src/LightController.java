import java.time.LocalDate;

public class LightController {
    private static final int LIGHT_COUNT = 7;

    public boolean[] getLightStates(LocalDate date, boolean holiday) {
        if (holiday) {
            return new boolean[LIGHT_COUNT];
        }

        boolean oddLightsOn = Utils.isOddPatternDay(date.getDayOfWeek());
        boolean[] states = new boolean[LIGHT_COUNT];
        for (int i = 0; i < LIGHT_COUNT; i++) {
            int lightNumber = i + 1;
            states[i] = oddLightsOn ? lightNumber % 2 == 1 : lightNumber % 2 == 0;
        }
        return states;
    }

    public String getPatternName(LocalDate date, boolean holiday) {
        if (holiday) {
            return "Holiday - No Lights";
        }

        boolean oddLightsOn = Utils.isOddPatternDay(date.getDayOfWeek());
        return Utils.patternName(holiday, oddLightsOn);
    }
}
