import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.ItemEvent;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableRowSorter;

public class StreetLightGUI extends JFrame {
    private final HolidayManager holidayManager = new HolidayManager();
    private final LightController lightController = new LightController();
    private final CalendarGenerator calendarGenerator = new CalendarGenerator(holidayManager, lightController);
    private final ExportManager exportManager = new ExportManager();

    private final JComboBox<Integer> yearCombo = new JComboBox<>();
    private final JComboBox<String> monthCombo = new JComboBox<>();
    private final JComboBox<Integer> dateCombo = new JComboBox<>();
    private final JTextField searchField = new JTextField(22);
    private final DefaultTableModel tableModel = new DefaultTableModel();
    private final JTable table = new JTable(tableModel);
    private final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
    private final DashboardPanel dashboardPanel = new DashboardPanel();
    private final JLabel statusRibbon = new JLabel("System Ready");
    private final List<LedIndicator> leds = new ArrayList<>();
    private List<ScheduleEntry> currentEntries = new ArrayList<>();

    public StreetLightGUI() {
        setTitle("Street Light Schedule");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1180, 760));
        setLocationRelativeTo(null);

        buildControls();
        buildTable();
        buildLayout();
        generateCalendar();
        pack();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    private void buildControls() {
        int currentYear = Year.now().getValue();
        for (int year = currentYear - Utils.PAST_YEAR_LIMIT;
                year <= currentYear + Utils.FUTURE_YEAR_LIMIT; year++) {
            yearCombo.addItem(year);
        }
        yearCombo.setSelectedItem(currentYear);
        for (Month month : Month.values()) {
            monthCombo.addItem(month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH));
        }
        monthCombo.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        updateDateCombo();

        yearCombo.addItemListener(event -> {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                updateDateCombo();
            }
        });
        monthCombo.addItemListener(event -> {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                updateDateCombo();
                applyFilters();
            }
        });
        dateCombo.addItemListener(event -> {
            if (event.getStateChange() == ItemEvent.SELECTED) {
                selectCurrentDate();
            }
        });
        searchField.getDocument().addDocumentListener(new SimpleDocumentListener(this::applyFilters));
    }

    private void buildTable() {
        tableModel.setColumnIdentifiers(new String[] {
                "Date", "Day", "Government Holiday", "Holiday Name", "Light Pattern", "Active Lights", "Status"
        });
        table.setRowSorter(sorter);
        table.setFillsViewportHeight(true);
        table.setRowHeight(32);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(11, 24, 35));
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));
        table.getTableHeader().setDefaultRenderer(new HeaderRenderer());
        table.setGridColor(new Color(210, 218, 224));
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setDefaultRenderer(Object.class, new TableRenderer());
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                updateSelectionFromTable();
            }
        });
    }

    private void buildLayout() {
        JPanel root = new DashboardBackgroundPanel();
        root.setLayout(new BorderLayout(12, 12));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        setContentPane(root);

        root.add(headerPanel(), BorderLayout.NORTH);
        root.add(centerPanel(), BorderLayout.CENTER);
        root.add(bottomPanel(), BorderLayout.SOUTH);
    }

    private JPanel headerPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Utils.BACKGROUND);

        panel.add(heroPanel(), BorderLayout.NORTH);
        panel.add(controlPanel(), BorderLayout.CENTER);
        panel.add(dashboardPanel, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel heroPanel() {
        GradientPanel hero = new GradientPanel(new Color(13, 32, 46), new Color(0, 109, 119));
        hero.setLayout(new BorderLayout(14, 4));
        hero.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setOpaque(false);
        JLabel title = new JLabel("Street Light Schedule");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 30));
        textPanel.add(title, BorderLayout.CENTER);

        statusRibbon.setOpaque(true);
        statusRibbon.setHorizontalAlignment(SwingConstants.CENTER);
        statusRibbon.setForeground(Color.WHITE);
        statusRibbon.setBackground(new Color(5, 44, 57));
        statusRibbon.setFont(new Font("Segoe UI", Font.BOLD, 13));
        statusRibbon.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(118, 255, 240)),
                BorderFactory.createEmptyBorder(10, 18, 10, 18)));

        hero.add(textPanel, BorderLayout.CENTER);
        hero.add(statusRibbon, BorderLayout.EAST);
        return hero;
    }

    private JPanel controlPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        panel.setBackground(Utils.PANEL_DARK);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(48, 64, 78)),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));

        JButton generateButton = button("Generate Calendar");
        JButton refreshButton = button("Refresh");
        JButton exportButton = button("Export CSV");
        JButton addHolidayButton = button("Add Holiday");
        JButton exitButton = button("Exit");

        generateButton.addActionListener(event -> generateCalendar());
        refreshButton.addActionListener(event -> refreshData());
        exportButton.addActionListener(event -> exportManager.exportCsv(this, currentEntries, selectedYear()));
        addHolidayButton.addActionListener(event -> showAddHolidayDialog());
        exitButton.addActionListener(event -> dispose());

        panel.add(label("Year"));
        panel.add(yearCombo);
        panel.add(label("Month"));
        panel.add(monthCombo);
        panel.add(label("Date"));
        panel.add(dateCombo);
        panel.add(generateButton);
        panel.add(refreshButton);
        panel.add(exportButton);
        panel.add(addHolidayButton);
        panel.add(exitButton);
        panel.add(label("Search"));
        panel.add(searchField);
        styleInputs();
        return panel;
    }

    private void styleInputs() {
        styleCombo(yearCombo);
        styleCombo(monthCombo);
        styleCombo(dateCombo);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        searchField.setForeground(new Color(13, 30, 42));
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(117, 206, 198)),
                BorderFactory.createEmptyBorder(7, 10, 7, 10)));
    }

    private void styleCombo(JComboBox<?> comboBox) {
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        comboBox.setBackground(Color.WHITE);
        comboBox.setForeground(new Color(13, 30, 42));
        comboBox.setBorder(BorderFactory.createLineBorder(new Color(117, 206, 198)));
    }

    private JPanel centerPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(14, 28, 39));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(58, 90, 106)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(48, 64, 78)));
        scrollPane.getViewport().setBackground(Color.WHITE);
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private JPanel lightPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Utils.PANEL_DARK);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(48, 64, 78)),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel title = new JLabel("Live Street Light Panel", SwingConstants.LEFT);
        title.setForeground(Utils.TEXT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        top.add(title, BorderLayout.WEST);
        top.add(legendPanel(), BorderLayout.EAST);
        panel.add(top, BorderLayout.NORTH);

        JPanel ledGrid = new JPanel(new GridLayout(1, 7, 16, 8));
        ledGrid.setBackground(Utils.PANEL_DARK);
        for (int i = 1; i <= 7; i++) {
            LedIndicator led = new LedIndicator(i);
            leds.add(led);
            ledGrid.add(led);
        }
        panel.add(ledGrid, BorderLayout.CENTER);
        return panel;
    }

    private JPanel bottomPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setOpaque(false);
        panel.add(lightPanel(), BorderLayout.CENTER);
        panel.add(footerPanel(), BorderLayout.SOUTH);
        return panel;
    }

    private JPanel footerPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 4, 0, 4));

        JLabel left = new JLabel("Smart City Lighting Grid | Java Swing | LocalDate | CSV Holiday Database");
        left.setForeground(Utils.MUTED_TEXT);
        left.setFont(new Font("Segoe UI", Font.BOLD, 12));

        JLabel right = new JLabel("Range: Past " + Utils.PAST_YEAR_LIMIT + " years to Next "
                + Utils.FUTURE_YEAR_LIMIT + " years");
        right.setForeground(new Color(142, 230, 220));
        right.setFont(new Font("Segoe UI", Font.BOLD, 12));

        panel.add(left, BorderLayout.WEST);
        panel.add(right, BorderLayout.EAST);
        return panel;
    }

    private JPanel legendPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        panel.setOpaque(false);
        panel.add(legendItem(Utils.ON, "ON"));
        panel.add(legendItem(Utils.OFF, "OFF"));
        panel.add(legendItem(Utils.HOLIDAY, "Holiday"));
        return panel;
    }

    private JPanel legendItem(Color color, String text) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        item.setOpaque(false);
        LedDot dot = new LedDot(color);
        JLabel label = new JLabel(text);
        label.setForeground(Utils.MUTED_TEXT);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        item.add(dot);
        item.add(label);
        return item;
    }

    private void generateCalendar() {
        currentEntries = calendarGenerator.generateYear(selectedYear());
        reloadTable(currentEntries);
        applyFilters();
        dashboardPanel.updateToday(holidayManager, lightController, selectedYear());
        selectCurrentDate();
    }

    private void refreshData() {
        holidayManager.reload();
        generateCalendar();
    }

    private void reloadTable(List<ScheduleEntry> entries) {
        tableModel.setRowCount(0);
        for (ScheduleEntry entry : entries) {
            tableModel.addRow(new Object[] {
                    Utils.formatDate(entry.getDate()),
                    entry.getDay(),
                    entry.isHoliday() ? "Yes" : "No",
                    entry.getHolidayName(),
                    entry.getLightPattern(),
                    entry.getActiveLights(),
                    entry.getStatus()
            });
        }
    }

    private void applyFilters() {
        String search = searchField.getText().trim().toLowerCase(Locale.ENGLISH);
        int month = monthCombo.getSelectedIndex() + 1;
        List<RowFilter<DefaultTableModel, Integer>> filters = new ArrayList<>();

        filters.add(new RowFilter<DefaultTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                LocalDate date = Utils.parseDate(entry.getStringValue(0));
                return date.getMonthValue() == month;
            }
        });

        if (!search.isEmpty()) {
            filters.add(new RowFilter<DefaultTableModel, Integer>() {
                @Override
                public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                    LocalDate date = Utils.parseDate(entry.getStringValue(0));
                    String monthName = Utils.monthName(date.getMonthValue()).toLowerCase(Locale.ENGLISH);
                    if (monthName.contains(search)) {
                        return true;
                    }
                    for (int column = 0; column < entry.getValueCount(); column++) {
                        String value = entry.getStringValue(column).toLowerCase(Locale.ENGLISH);
                        if (value.contains(search)) {
                            return true;
                        }
                    }
                    return false;
                }
            });
        }

        sorter.setRowFilter(RowFilter.andFilter(filters));
    }

    private void selectCurrentDate() {
        if (dateCombo.getSelectedItem() == null || currentEntries.isEmpty()) {
            return;
        }
        LocalDate selected = LocalDate.of(selectedYear(), monthCombo.getSelectedIndex() + 1,
                (Integer) dateCombo.getSelectedItem());
        for (ScheduleEntry entry : currentEntries) {
            if (entry.getDate().equals(selected)) {
                updateDashboardAndLights(entry);
                selectTableRow(selected);
                return;
            }
        }
    }

    private void selectTableRow(LocalDate date) {
        String target = Utils.formatDate(date);
        for (int row = 0; row < table.getRowCount(); row++) {
            int modelRow = table.convertRowIndexToModel(row);
            if (target.equals(tableModel.getValueAt(modelRow, 0))) {
                table.getSelectionModel().setSelectionInterval(row, row);
                table.scrollRectToVisible(table.getCellRect(row, 0, true));
                return;
            }
        }
    }

    private void updateSelectionFromTable() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            return;
        }
        int modelRow = table.convertRowIndexToModel(viewRow);
        LocalDate date = Utils.parseDate((String) tableModel.getValueAt(modelRow, 0));
        for (ScheduleEntry entry : currentEntries) {
            if (entry.getDate().equals(date)) {
                dateCombo.setSelectedItem(date.getDayOfMonth());
                updateDashboardAndLights(entry);
                return;
            }
        }
    }

    private void updateDashboardAndLights(ScheduleEntry entry) {
        dashboardPanel.updateDashboard(entry, selectedYear(), holidayManager.getHolidaysForYear(selectedYear()).size(),
                holidayManager.getNextHoliday(entry.getDate()));
        statusRibbon.setText(entry.getDay() + " " + Utils.formatDate(entry.getDate()) + " | "
                + entry.getStatus() + " | Active: " + entry.getActiveLights());
        statusRibbon.setBackground(entry.isHoliday() ? new Color(124, 32, 42) : new Color(5, 84, 75));
        boolean holidayMode = entry.isHoliday();
        boolean[] states = entry.getLightStates();
        for (int i = 0; i < leds.size(); i++) {
            leds.get(i).setState(states[i], holidayMode);
        }
    }

    private void showAddHolidayDialog() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 8, 8));
        SpinnerDateModel dateModel = new SpinnerDateModel();
        JSpinner dateSpinner = new JSpinner(dateModel);
        dateSpinner.setEditor(new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd"));
        JTextField nameField = new JTextField();
        panel.add(new JLabel("Date"));
        panel.add(dateSpinner);
        panel.add(new JLabel("Holiday Name"));
        panel.add(nameField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Custom Government Holiday",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            java.util.Date utilDate = (java.util.Date) dateSpinner.getValue();
            LocalDate date = utilDate.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
            holidayManager.addCustomHoliday(date, nameField.getText());
            generateCalendar();
            monthCombo.setSelectedIndex(date.getMonthValue() - 1);
            dateCombo.setSelectedItem(date.getDayOfMonth());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Could Not Add Holiday", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateDateCombo() {
        Integer selectedDay = (Integer) dateCombo.getSelectedItem();
        dateCombo.removeAllItems();
        int year = selectedYear();
        int month = monthCombo.getSelectedIndex() + 1;
        int maxDays = Month.of(month).length(Year.isLeap(year));
        for (int day = 1; day <= maxDays; day++) {
            dateCombo.addItem(day);
        }
        int todayDay = LocalDate.now().getDayOfMonth();
        int preferred = selectedDay == null ? todayDay : Math.min(selectedDay, maxDays);
        dateCombo.setSelectedItem(Math.max(1, Math.min(preferred, maxDays)));
    }

    private int selectedYear() {
        Object item = yearCombo.getSelectedItem();
        return item == null ? Year.now().getValue() : (Integer) item;
    }

    private JButton button(String text) {
        JButton button = new JButton(text);
        button.setUI(new BasicButtonUI());
        button.setFocusPainted(false);
        button.setBackground(new Color(0, 150, 136));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(88, 255, 238), 1),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setRolloverEnabled(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private JLabel label(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Utils.TEXT);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        return label;
    }

    private static class LedIndicator extends JPanel {
        private final int number;
        private boolean on;
        private boolean holidayMode;
        private float pulse = 0.0f;

        LedIndicator(int number) {
            this.number = number;
            setPreferredSize(new Dimension(110, 86));
            setOpaque(false);
        }

        void setState(boolean on, boolean holidayMode) {
            this.on = on;
            this.holidayMode = holidayMode;
            this.pulse = 1.0f;
            Timer timer = new Timer(35, null);
            timer.addActionListener(event -> {
                pulse -= 0.08f;
                if (pulse <= 0.0f) {
                    pulse = 0.0f;
                    timer.stop();
                }
                repaint();
            });
            timer.start();
            repaint();
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(new Color(12, 24, 34));
            g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 18, 18);
            g2.setColor(new Color(48, 70, 86));
            g2.drawRoundRect(2, 2, getWidth() - 5, getHeight() - 5, 18, 18);

            int size = Math.min(getWidth() - 42, getHeight() - 45);
            int x = (getWidth() - size) / 2;
            int y = 10;
            Color color = on ? (holidayMode ? Utils.HOLIDAY : Utils.ON) : Utils.OFF;

            int glow = Math.round(10 + pulse * 16);
            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 70));
            g2.fillOval(x - glow / 2, y - glow / 2, size + glow, size + glow);
            g2.setColor(color);
            g2.fillOval(x, y, size, size);
            g2.setColor(new Color(255, 255, 255, 120));
            g2.fillOval(x + size / 5, y + size / 6, size / 4, size / 4);
            g2.setColor(Utils.TEXT);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
            String label = "Light " + number;
            int textWidth = g2.getFontMetrics().stringWidth(label);
            g2.drawString(label, (getWidth() - textWidth) / 2, getHeight() - 24);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
            g2.setColor(on ? color : Utils.MUTED_TEXT);
            String stateText = on ? "ON" : "OFF";
            int stateWidth = g2.getFontMetrics().stringWidth(stateText);
            g2.drawString(stateText, (getWidth() - stateWidth) / 2, getHeight() - 8);
            g2.dispose();
        }
    }

    private static class HeaderRenderer extends DefaultTableCellRenderer {
        HeaderRenderer() {
            setOpaque(true);
            setHorizontalAlignment(SwingConstants.LEFT);
            setFont(new Font("Segoe UI", Font.BOLD, 13));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 2, 1, new Color(0, 150, 136)),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setText(value == null ? "" : value.toString());
            setBackground(new Color(11, 24, 35));
            setForeground(Color.WHITE);
            return this;
        }
    }

    private static class DashboardBackgroundPanel extends JPanel {
        DashboardBackgroundPanel() {
            setOpaque(true);
            setBackground(Utils.BACKGROUND);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setPaint(new GradientPaint(0, 0, new Color(10, 20, 30),
                    getWidth(), getHeight(), new Color(20, 42, 54)));
            g2.fillRect(0, 0, getWidth(), getHeight());

            paintGrid(g2);
            paintRoadLines(g2);
            paintSkyline(g2);

            g2.dispose();
        }

        private void paintGrid(Graphics2D g2) {
            g2.setColor(new Color(92, 190, 180, 22));
            for (int x = 0; x < getWidth(); x += 42) {
                g2.drawLine(x, 0, x, getHeight());
            }
            for (int y = 0; y < getHeight(); y += 42) {
                g2.drawLine(0, y, getWidth(), y);
            }
        }

        private void paintRoadLines(Graphics2D g2) {
            int baseY = Math.max(160, getHeight() - 170);
            g2.setColor(new Color(0, 220, 205, 45));
            g2.drawLine(0, baseY, getWidth(), baseY - 40);
            g2.drawLine(0, baseY + 54, getWidth(), baseY + 10);
            g2.setColor(new Color(255, 210, 92, 45));
            for (int x = 20; x < getWidth(); x += 92) {
                g2.fillRoundRect(x, baseY + 24, 42, 4, 6, 6);
            }
        }

        private void paintSkyline(Graphics2D g2) {
            int ground = getHeight() - 18;
            g2.setColor(new Color(7, 17, 25, 150));
            for (int x = 0; x < getWidth(); x += 58) {
                int height = 36 + (x / 58 % 5) * 10;
                g2.fillRect(x, ground - height, 38, height);
                g2.setColor(new Color(0, 210, 195, 38));
                g2.fillRect(x + 8, ground - height + 10, 6, 5);
                g2.fillRect(x + 23, ground - height + 22, 6, 5);
                g2.setColor(new Color(7, 17, 25, 150));
            }
        }
    }

    private static class GradientPanel extends JPanel {
        private final Color start;
        private final Color end;

        GradientPanel(Color start, Color end) {
            this.start = start;
            this.end = end;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setPaint(new GradientPaint(0, 0, start, getWidth(), getHeight(), end));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            g2.setColor(new Color(95, 255, 238, 80));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.dispose();
        }
    }

    private static class LedDot extends JPanel {
        private final Color color;

        LedDot(Color color) {
            this.color = color;
            setOpaque(false);
            setPreferredSize(new Dimension(12, 12));
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g2 = (Graphics2D) graphics.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.fillOval(1, 1, 10, 10);
            g2.dispose();
        }
    }
}
