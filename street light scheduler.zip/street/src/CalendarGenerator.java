import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CalendarGenerator {
    private final HolidayManager holidayManager;
    private final LightController lightController;

    public CalendarGenerator(HolidayManager holidayManager, LightController lightController) {
        this.holidayManager = holidayManager;
        this.lightController = lightController;
    }

    public List<ScheduleEntry> generateYear(int year) {
        List<ScheduleEntry> entries = new ArrayList<>();
        LocalDate date = LocalDate.of(year, 1, 1);
        int days = Year.isLeap(year) ? 366 : 365;

        for (int i = 0; i < days; i++) {
            Optional<Holiday> holiday = holidayManager.getHoliday(date);
            boolean isHoliday = holiday.isPresent();
            String holidayName = holiday.map(Holiday::getName).orElse("-");
            boolean[] states = lightController.getLightStates(date, isHoliday);
            entries.add(new ScheduleEntry(
                    date,
                    Utils.dayName(date),
                    isHoliday,
                    holidayName,
                    lightController.getPatternName(date, isHoliday),
                    Utils.activeLightsText(states),
                    isHoliday ? "Holiday Mode" : "Normal",
                    states));
            date = date.plusDays(1);
        }

        return entries;
    }
}
