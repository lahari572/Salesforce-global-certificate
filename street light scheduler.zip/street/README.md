# Street Light Schedule

A Java Swing desktop mini project that generates a smart street light schedule for any year from the past 25 years through the next 50 years. It supports leap years, Indian Government Holiday mode, custom holidays, dashboard statistics, search, LED animation, and CSV export.

## Features

- Java 17+ Swing application
- MVC-style separation using manager, generator, controller, renderer, export, and GUI classes
- Seven live circular LED indicators
- Normal day schedule:
  - Monday, Wednesday, Friday, Sunday: Lights 1, 3, 5, 7 ON
  - Tuesday, Thursday, Saturday: Lights 2, 4, 6 ON
- Holiday rule:
  - If the date is an Indian Government Holiday, all street lights remain OFF
- Calendar generation for 365 and 366 day years
- Year selection from past 25 years through next 50 years
- Month and date selection
- Dashboard for current selected date
- Connected smart-area cards for Army Area, Medical Area, Camera Network, Reduced Cameras, Cloud Control, Phone One-Click, School Zone, and Market Area
- Search by date, day, month text in date, holiday name, light pattern, active lights, and status
- CSV export
- Custom holiday entry stored in `data/custom_holidays.csv`

## Project Structure

```text
street/
  data/
    holidays.csv
    custom_holidays.csv
  src/
    Main.java
    StreetLightGUI.java
    HolidayManager.java
    CalendarGenerator.java
    LightController.java
    DashboardPanel.java
    TableRenderer.java
    ExportManager.java
    Utils.java
    Holiday.java
    ScheduleEntry.java
    SimpleDocumentListener.java
  README.md
```

The requested files are included. `Holiday.java`, `ScheduleEntry.java`, and `SimpleDocumentListener.java` are small support classes used to keep the main classes clean.

## Holiday Data Design

The application does not hardcode all holidays for the full supported year range.

It uses:

- Built-in rule-based national holidays for every supported year:
  - Army Day, January 15
  - Republic Day, January 26
  - Doctors' Day / Health Checkup Day, July 1
  - Independence Day, August 15
  - Gandhi Jayanti, October 2
- Updatable CSV database: `data/holidays.csv`
- User-added custom holidays: `data/custom_holidays.csv`

Movable Indian Government Holidays such as Holi, Eid, Dussehra, Diwali, and Guru Nanak Jayanti can be updated in the CSV file year by year without changing Java code.

CSV format:

```csv
date,name
2026-11-08,Diwali
```

## VS Code Setup

1. Install JDK 17 or newer.
2. Install Visual Studio Code.
3. Install the extension pack: `Extension Pack for Java`.
4. Open this folder in VS Code:

```text
C:\Users\Lenovo\Downloads\street
```

5. Open `src/Main.java`.
6. Click `Run` above the `main` method, or use the terminal command below.

## Compile and Run From Terminal

Run these commands from the project root:

```powershell
javac -d out src\*.java
java -cp out Main
```

Run the included logic tests:

```powershell
javac -d out src\*.java
java -cp out SchedulerTest
```

## Eclipse Setup

1. Open Eclipse.
2. Select `File > New > Java Project`.
3. Project name: `SmartStreetLightScheduler`.
4. Set JRE to Java 17 or newer.
5. Copy the `src` folder files into the Eclipse `src` folder.
6. Copy the `data` folder into the project root.
7. Right click `Main.java`.
8. Select `Run As > Java Application`.

## How To Use

1. Select a year.
2. Select a month and date.
3. Click `Generate Calendar`.
4. View the complete schedule in the table.
5. Use the search box to filter by date, day, holiday name, active lights, or status.
6. Click `Add Holiday` to add a custom government holiday.
7. Click `Export CSV` to export the yearly schedule.
8. Click `Refresh` after manually editing holiday CSV files.

## Test Cases

| Test Case | Input | Expected Result |
| --- | --- | --- |
| Normal Monday | Non-holiday Monday | Lights 1, 3, 5, 7 ON |
| Holiday Monday | Monday marked as holiday | No lights ON and status Holiday Mode |
| Normal Tuesday | Non-holiday Tuesday | Lights 2, 4, 6 ON |
| Holiday Tuesday | Tuesday marked as holiday | No lights ON and status Holiday Mode |
| Leap year | 2028 | Calendar generates 366 rows |
| Non-leap year | 2027 | Calendar generates 365 rows |
| National holiday | Any supported year January 26 | Republic Day appears automatically |
| Army Day | Any supported year January 15 | Army Day appears automatically |
| Doctors' Day | Any supported year July 1 | Doctors' Day / Health Checkup Day appears automatically |
| Custom holiday | Add a date using Add Holiday | Date becomes Holiday Mode |
| Export | Click Export CSV | CSV file contains all generated rows |

## Code Explanation

- `Main.java`: Starts the Swing application.
- `StreetLightGUI.java`: Main dashboard, controls, table, search, and LED panel.
- `HolidayManager.java`: Loads built-in national holidays, CSV holidays, and custom holidays.
- `CalendarGenerator.java`: Generates the yearly schedule.
- `LightController.java`: Applies normal patterns and switches all lights off on government holidays.
- `DashboardPanel.java`: Shows selected date statistics.
- `TableRenderer.java`: Highlights holiday rows.
- `ExportManager.java`: Exports schedules to CSV.
- `Utils.java`: Shared colors, date formatting, and helper methods.

## Notes

PDF export is optional in the project requirement and is not included because this project uses only standard Java libraries. CSV export is fully implemented and works without external dependencies.
